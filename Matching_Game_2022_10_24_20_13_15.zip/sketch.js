function setup() {
  //create inital screen
  createCanvas(500, 500);
  background("rgb(176,241,230)");
  fill('grey');
  rect(0, 0, 150, 500);
  
  //text and buttons
  textSize(32);
  fill('black');
  text('Shapes', 20, 50);
  
  textSize(32);
  text('Matching area', 225, 50);
  

}

function draw() {
  //create shapes
  line(150, 500, 150, 0);
  fill('white');
  
  square(50, 70, 50);
  
  triangle(75, 145, 40, 190, 110, 190);
  
  circle(75, 240, 50);
  
  polygon(75, 320, 30, 5);
  
  diamond(50, 50);

  
  
}

//functions 

function polygon(x, y, radius, npoints) {
  let angle = TWO_PI / npoints;
  beginShape();
  for (let a = 0; a < TWO_PI; a += angle) {
    let sx = x + cos(a) * radius;
    let sy = y + sin(a) * radius;
    vertex(sx, sy);
  }
  endShape(CLOSE);
}

function diamond(x1, y1, x2, y2) {
  beginShape();
  vertex(75, 375);
  vertex(50, 425);
  vertex(75, 475);
  vertex(100, 425);
  endShape();
}
