function setup() {
  createCanvas(600,400);
  background(220);
  
  rect(0,0,200,400);
textSize(24);
text('Line Type', 45, 30);
text('Tracing', 350,30);
  
  fill('red');
  rect(50,75,100,25);
  
  fill('blue');
  rect(50,150,25,50);
  rect(50,175,100,25);
  rect(125,175,25,50);
  
noFill();
stroke('green');
strokeWeight(20);
beginShape();
vertex(52,350)
vertex(60, 325);
quadraticVertex(82, 250, 97, 325);
quadraticVertex(112, 375, 127, 325);
quadraticVertex(142, 250, 157, 350);

endShape();
}

function draw() {

}

