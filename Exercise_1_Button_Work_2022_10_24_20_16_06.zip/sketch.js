var button;
var menuButton;

function setup() {
  createCanvas(700, 500);
  background(130);
  
  rect(0, 0, 200, 500);
  
  button = createButton("Help");
  button.size(50,50);
  button.position(535,15);
  button.mouseClicked(changeBack);
  
  menuButton = createButton("Menu");
  menuButton.size(50,385);
  menuButton.position(535,100);
  menuButton.mouseClicked(changeBack);
  
}

function changeBack() {
      
    // Pick a random number for r value
    r = random(255);
      
    // Pick a random number for g value
    g = random(255);
      
    // Pick a random number for b value
    b = random(255);
      
    // Set a random background-color
    background(r, g, b);
}

function draw() {
  
  textSize(30);
  text("Shapes",50,40);
  
  textSize(30);
  text("Match Here", 300,40)
  
  square(30,80,50);
  
  circle(140,190,50);
  
}


