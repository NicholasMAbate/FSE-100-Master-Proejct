function setup() {
  createCanvas(700, 500);
    background(' blue');
  let c = color(51, 201, 700);
  
  fill(c);
  rect(200, 600, 400, 600);
  let value = hue(c); // Sets 'value' to "0"
  
  fill(value);
  rect(0, 0, 250, 500);
  
  fill('red');
rect(50, 0, 200, 700);
describe('red rect with black outline in center of canvas');
}

function draw() {

textSize(50);
text('Shapes', 70, 50);
fill(0, 1, 153);
describe('black fill with red outline');
  fill(51);
describe('dark charcoal grey rect with black outline in center of canvas');
  
  textSize(50);
text('Drawing Area', 300, 50);
fill(0, 1, 153);
describe('black fill with red outline');
  fill(51);
describe('dark charcoal grey rect with red outline in center of canvas');
  
  square(75, 100, 50);
describe('white square with black outline in mid-right of canvas');
  
  triangle(75, 250, 125, 250, 100, 190);
describe('white triangle with black outline in mid-right of canvas');
  
  circle(200, 125, 50);
describe('white circle with black outline in mid of gray canvas');
  
  
  
}
